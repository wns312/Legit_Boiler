//유저정보
export const LOGIN_USER = 'login_user';
export const REGISTER_USER = 'register_user';
export const AUTH_USER = 'auth_user';
//채팅정보
export const SOCKET = 'socket';
export const NS_LIST = 'ns_list';
export const CURRENT_NS = 'current_ns';
export const ROOM_LIST = 'room_list';
export const CURRENT_ROOM = 'current_room';
//스케쥴정보
export const SCHEDULE_LIST = 'schedule_list';
export const CURRENT_SCHEDULE = 'current_schedule';

